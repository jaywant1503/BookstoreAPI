﻿namespace EFCoreDatabaseFirstSample.Models.DTO
{
    public class AuthorContactDto
    {
        public AuthorContactDto()
        {
        }

        public long AuthorId { get; set; }

        public string ContactNumber { get; set; }

        public string Address { get; set; }
    }
}
