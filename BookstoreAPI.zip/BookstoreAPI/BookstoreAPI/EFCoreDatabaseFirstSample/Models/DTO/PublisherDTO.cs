﻿namespace EFCoreDatabaseFirstSample.Models.DTO
{
    public class PublisherDto
    {
        public long Id { get; set; }
        public string Name { get; set; }
    }
}
